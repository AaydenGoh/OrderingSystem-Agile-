// author : Goh Weng Yong 
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame{
    private JTextField input = new JTextField();
    private JPasswordField logPass = new JPasswordField();
    private JLabel[] label = {new JLabel("Username"),new JLabel("Password")};
    private JButton logIn = new JButton("Log In");
    private JButton ntg = new JButton();
    private String userName = "Goh Weng Yong";
    private String password = "12345";
    public Login(){
        
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3,2));
        panel.add(label[0]);
        panel.add(input);
        panel.add(label[1]);
        panel.add(logPass);
        logPass.setEchoChar('*');
        panel.add(ntg);
        ntg.setVisible(false);
        panel.add(logIn);
        for(int i=0;i<2;i++){
            label[i].setHorizontalAlignment(SwingConstants.RIGHT);
        }
        
        logIn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                String user = input.getText();
                String pass = logPass.getText();
                
                if(!user.equals(userName)||!pass.equals(password))
                    JOptionPane.showMessageDialog(null,"Invalid username or password!","Cautious",JOptionPane.PLAIN_MESSAGE);
                else{
                    JOptionPane.showMessageDialog(null,"Welcome to XXX System","Log in success",JOptionPane.PLAIN_MESSAGE);
                    //new DataManageFrame();
                    //close();
                }
            }
        });
        
        add(panel,BorderLayout.SOUTH);
        
        setTitle("Restaurant All 1 System");
        setSize(600,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    public void close(){

        WindowEvent winClosingEvent = new WindowEvent(this,WindowEvent.WINDOW_CLOS­ING);
        Toolkit.getDefaultToolkit().getSystemEve­ntQueue().postEvent(winClosingEvent);

    }

    public static void main(String[] args){
        new Login();
    }
}
